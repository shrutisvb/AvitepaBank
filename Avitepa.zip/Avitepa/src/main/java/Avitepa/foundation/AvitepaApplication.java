package Avitepa.foundation;

import java.util.ArrayList;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;

import Avitepa.foundation.Model.Account;
import Avitepa.foundation.Model.AccountRepository;

@SpringBootApplication
public class AvitepaApplication {

	@Autowired
	AccountRepository accountRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(AvitepaApplication.class, args);
	}
   
}
