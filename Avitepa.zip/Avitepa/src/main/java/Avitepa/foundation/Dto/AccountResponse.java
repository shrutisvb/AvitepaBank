package Avitepa.foundation.Dto;

public class AccountResponse {

	private String customer_name;
	private String account_type;
	private int account_balance;
	public AccountResponse() {
		
	}
	
	public AccountResponse(String customer_name, String account_type, int account_balance) {
		super();
		this.customer_name = customer_name;
		this.account_type = account_type;
		this.account_balance = account_balance;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public int getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(int account_balance) {
		this.account_balance = account_balance;
	}
	
}
