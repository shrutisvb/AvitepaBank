package Avitepa.foundation.Dto;

import Avitepa.foundation.Model.Customer;


public class AccountRequest {

	private Customer customer;
	public AccountRequest() {
	
	}

	public AccountRequest(Customer customer) {
		super();
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "AccountRequest [customer=" + customer + "]";
	}
	
}
