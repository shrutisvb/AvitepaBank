package Avitepa.foundation.Model;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import Avitepa.foundation.Dto.AccountResponse;

public interface CustomerRepository extends CrudRepository<Customer, Long> {

	@Query("select new Avitepa.foundation.Dto.AccountResponse(c.customer_name,a.account_type,a.account_balance) From Customer c JOIN c.accounts a")
	public List<AccountResponse> getCustomerInformation();
}  