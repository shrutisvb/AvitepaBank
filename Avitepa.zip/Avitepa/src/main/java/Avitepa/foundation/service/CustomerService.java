package Avitepa.foundation.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Avitepa.foundation.Model.Customer;
import Avitepa.foundation.Model.CustomerRepository;

@Service
public class CustomerService {

	private final CustomerRepository customerRepository;
	
	public CustomerService(CustomerRepository customerRepository) {
		super();
		this.customerRepository = customerRepository;
	}
	
	public void update(Customer customer, int customerid)   
	{  
		customerRepository.save(customer);  
	}  
	
	public void saveOrUpdate(Customer customer)   
	{  
		customerRepository.save(customer);  
	}  

	public void delete(long id)   
	{  
		customerRepository.deleteById((long) id);  
	}  

	public void deleteAll()   
	{  
		customerRepository.deleteAll();  
	} 
	
    public Customer findById(Long id) {
        return customerRepository.findById(id).get();
    }
	
	public List<Customer> findAll()
	{
		
		List<Customer> employees = new ArrayList<Customer>(); 
		customerRepository.findAll().forEach(employees1 ->employees.add(employees1));  
		return employees;  
	}




}
