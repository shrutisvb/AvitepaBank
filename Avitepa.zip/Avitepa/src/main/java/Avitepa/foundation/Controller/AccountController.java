package Avitepa.foundation.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import Avitepa.foundation.Dto.AccountRequest;
import Avitepa.foundation.Dto.AccountResponse;
import Avitepa.foundation.Model.Account;
import Avitepa.foundation.Model.AccountRepository;
import Avitepa.foundation.Model.Customer;
import Avitepa.foundation.Model.CustomerRepository;
import Avitepa.foundation.service.CustomerService;

@RestController
public class AccountController {
	@Autowired
	private AccountRepository accountRepository;
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	

	@PostMapping("/createAccount")
	public Customer createAccount(@RequestBody AccountRequest request) {
		return customerRepository.save(request.getCustomer());
	}
	
	@GetMapping("/findAllAccounts")
	public List<Customer> findAllAccounts(){
		return (List<Customer>) customerRepository.findAll();
	}
	
	@GetMapping("/findAccount/{id}")
	public List<Customer> findAccountsById(@PathVariable long id){
		return (List<Customer>) customerService.findById(id);
	}
	
	@GetMapping("/getInfo")
	public List<AccountResponse> getCustomerInformation(){
		return customerRepository.getCustomerInformation();
	}
	
	@RequestMapping("/display/{id}")
	public Optional<Customer> getEmployeebyId(@PathVariable long id){
		return customerRepository.findById(id);
	}
	
	@DeleteMapping("/delete/{id}")  
	private String deleteEmployee(@PathVariable("id") int id)   
	{  
		customerService.delete(id); 
		return "Success";
	}  
	@PutMapping("/transfer")
	public String transferfunds(@RequestParam long sid,@RequestParam long rid, @RequestParam int funds) {
		int sender_balance;
		int receiver_balance;
		Account a=new Account();
		sender_balance=accountRepository.findById(sid).get().getAccount_balance();
		receiver_balance=accountRepository.findById(rid).get().getAccount_balance();
		if(sender_balance>funds) {
			receiver_balance=receiver_balance+funds;
			a=accountRepository.findById(rid).get();
			a.setAccount_balance(receiver_balance);
			accountRepository.save(a);
			sender_balance=sender_balance-funds;
			a=accountRepository.findById(sid).get();
			a.setAccount_balance(sender_balance);
			accountRepository.save(a);
			return "Successfully Transfered";
		}
		else {
			return "Insufficient Balance";
		}
		
	}
	
	@GetMapping("/findAll")
	private List<Customer> findAllAccount()   
	{  
	return customerService.findAll();  
	} 
	
	@PutMapping("/update")  
	private Customer update(@RequestBody Customer customer)   
	{  
	 customerService.saveOrUpdate(customer);  
	return customer;  
	}  
	@PostMapping("/create")  
	private Customer create(@RequestBody Customer customer)   
	{  
	 customerService.saveOrUpdate(customer);  
	return customer;  
	}  
	

}
