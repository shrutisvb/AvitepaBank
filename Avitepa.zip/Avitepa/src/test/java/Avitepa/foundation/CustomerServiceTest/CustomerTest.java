package Avitepa.foundation.CustomerServiceTest;

import static org.hamcrest.CoreMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Sort;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import Avitepa.foundation.Controller.AccountController;
import Avitepa.foundation.Model.Account;
import Avitepa.foundation.Model.Customer;
import Avitepa.foundation.Model.CustomerRepository;
import Avitepa.foundation.service.CustomerService;
import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class CustomerTest {

	private CustomerService customerService;
	private CustomerRepository customerRepository;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	// FindAll Test
	@Test
	public void findAll() {
		customerRepository = mock(CustomerRepository.class);
		customerService = new CustomerService(customerRepository);
		List<Customer> customer = new ArrayList<>();
		List<Account> acc = new ArrayList<Account>();
		Account acc1 = new Account("Saving", 560090);
		acc.add(acc1);
		Account acc2 = new Account("Personal", 560090);
		acc.add(acc2);

		Customer c = new Customer(1, "Shruti", "654546664", acc);
		customer.add(c);
		when(customerRepository.findAll()).thenReturn(customer);
		System.out.println(c);
		customerService.saveOrUpdate(c);
		List<Customer> expectedList = customerService.findAll();

		assertEquals(1, expectedList.size());
	}

	// Test for findById
	@Test
	public void findbyId() {
		customerRepository = mock(CustomerRepository.class);
		customerService = new CustomerService(customerRepository);
		Customer c = new Customer();
		Mockito.when(customerRepository.findById((long) 1)).thenReturn(Optional.ofNullable(c));

	}

	// Delete By ID-Test
	@Test
	public void deleteByIdTest() {
		customerRepository = mock(CustomerRepository.class);
		customerService = new CustomerService(customerRepository);
		customerService.delete(1);

		verify(customerRepository, times(1)).deleteById((long) 1);

	}

	// Delete ALL Test
	@Test
	public void deleteAllTest() {
		customerRepository = mock(CustomerRepository.class);
		customerService = new CustomerService(customerRepository);
		customerService.deleteAll();
		verify(customerRepository, times(1)).deleteAll();

	}

	@Test
	public void NullTest() {
		customerRepository = mock(CustomerRepository.class);
		customerService = new CustomerService(customerRepository);
		Assert.assertNotNull(customerService);
	}
	

	/*
	 * @Test public void testUpdateProduct() { customerRepository =
	 * mock(CustomerRepository.class); customerService = new
	 * CustomerService(customerRepository); Optional<Customer> cust =
	 * customerRepository.findById((long) 1); Assert.assertNotNull(cust);
	 * 
	 * List<Account> acc = new ArrayList<Account>(); Account acc1=new
	 * Account("Saving",560090); acc.add(acc1); Account acc2=new
	 * Account("Personal",560090); acc.add(acc2); cust.setAccounts(acc);
	 * customerService.saveOrUpdate(cust); Customer updatedProduct
	 * =customerService.findById((long) 1);
	 * 
	 * //System.out.println(updatedProduct);
	 * 
	 * // verify(customerRepository, times(1)).save(updatedProduct); //
	 * Assert.assertEquals(updatedProduct.getAccounts(), cust); }
	 */

	// Test for Saving
	@Test
	public void savingTest() {
		customerRepository = mock(CustomerRepository.class);
		customerService = new CustomerService(customerRepository);
		List<Account> acc = new ArrayList<Account>();
		Account acc1 = new Account("Saving", 560090);
		acc.add(acc1);
		Account acc2 = new Account("Personal", 560090);
		acc.add(acc2);
		Customer c = new Customer(1, "Shruti", "654546664", acc);
		customerService.saveOrUpdate(c);
		verify(customerRepository, times(1)).save(c);
	}

}
