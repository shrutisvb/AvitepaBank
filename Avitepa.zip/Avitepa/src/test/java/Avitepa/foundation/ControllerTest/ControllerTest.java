package Avitepa.foundation.ControllerTest;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import Avitepa.foundation.Controller.AccountController;
import Avitepa.foundation.Model.Account;
import Avitepa.foundation.Model.Customer;
import Avitepa.foundation.Model.CustomerRepository;
import Avitepa.foundation.service.CustomerService;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ControllerTest {
	 @Autowired
	    private MockMvc mockMvc;
		private CustomerRepository customerRepository;

	    @MockBean
	    private CustomerService customerService;

	    @Autowired
	    private ObjectMapper objectMapper;

	    private List<Customer> customerList;
	    
	    public static String asJsonString(final Object obj) {
	        try {
	            final ObjectMapper mapper = new ObjectMapper();
	            final String jsonContent = mapper.writeValueAsString(obj);
	            System.out.println(jsonContent);
	            return jsonContent;
	        } catch (Exception e) {
	            throw new RuntimeException(e);
	        }
	    }
	    @BeforeEach
	    void setUp() {
	        this.customerList = new ArrayList<>();
	        List<Account> acc = new ArrayList<Account>();
			Account acc1 = new Account("Saving", 560090);
			acc.add(acc1);
			Account acc2 = new Account("Personal", 560090);
			acc.add(acc2);

	        this.customerList.add(new Customer(1L, "Shruti","46576", acc)); 
	      //  objectMapper.registerModule(new ProblemModule());
	       // objectMapper.registerModule(new ConstraintViolationProblemModule());
	    }
	    
	    @Test
	    void getMethodTest() throws Exception {
	        final Long cId = 1L;
	        List<Account> acc = new ArrayList<Account>();
			Account acc1 = new Account("Saving", 560090);
			acc.add(acc1);
			Account acc2 = new Account("Personal", 560090);
			acc.add(acc2);

	       
	        final Customer cust = new Customer(cId, "Shruti","46576", acc);

	        Mockito.when(customerService.findById(cId)).thenReturn((cust));

	        this.mockMvc.perform(get("/display/{id}", cId))
	                .andExpect(status().isOk());
	    }
	    
	    @Test
	    void shouldCreateNewUser() throws Exception {
	    	customerRepository = mock(CustomerRepository.class);
	    	customerService = new CustomerService(customerRepository);
			List<Account> acc = new ArrayList<Account>();
			Account acc1 = new Account("Saving", 560090);
			acc.add(acc1);
			Account acc2 = new Account("Personal", 560090);
			acc.add(acc2);
			Customer c = new Customer();
			c.setId(1L);
			c.setCustomer_name("Shru");
			c.setAdhar_card("4545656766");
			c.setAccounts(acc);
			customerService.saveOrUpdate(c);
     	    mockMvc.perform(post("/create")
			        .contentType(MediaType.APPLICATION_JSON)
			        .content(asJsonString(c))
			        .accept(MediaType.APPLICATION_JSON))
			        .andDo(print())
			        .andExpect(status().isOk());
	    }
	    @Test
	    void putMappingTest() throws Exception{
	    	customerRepository = mock(CustomerRepository.class);
	    	customerService = new CustomerService(customerRepository);
			List<Account> acc = new ArrayList<Account>();
			Account acc1 = new Account("Saving", 560090);
			acc.add(acc1);
			Account acc2 = new Account("Personal", 560090);
			acc.add(acc2);
			Customer c = new Customer(1, "Shruti", "654546664", acc);
			customerService.saveOrUpdate(c);

			mockMvc.perform(put("/update")
			        .contentType(MediaType.APPLICATION_JSON)
			        .content(asJsonString(c))
			        .accept(MediaType.APPLICATION_JSON))
			        .andDo(print())
			        .andExpect(status().isOk());
	    }
	    @Test
	    void Tranfer() throws Exception{
	    	customerRepository = mock(CustomerRepository.class);
	    	customerService = new CustomerService(customerRepository);
	    	long sid=1;
	    	long rid=2;
	    	int sender_balance=1400;
			int receiver_balance=400;
			int funds=400;
			Account a1=new Account();
			Account a2=new Account();
			//sender_balance=customerRepository.findById(sid).get().getAccount_balance();
			//receiver_balance=customerRepository.findById(rid).get().getAccount_balance();
		    a1.setId(sid);
            a1.setAccount_type("Saving");
            a1.setAccount_balance(sender_balance-receiver_balance);
            a2.setId(rid);
            a2.setAccount_type("Paying");
            a2.setAccount_balance(sender_balance+receiver_balance);
            List<Account> acc1 = new ArrayList<Account>();
            acc1.add(a1);
          Customer user1 = new Customer(1L, "Shruti", "4560965409", acc1);
          List<Account> acc2 = new ArrayList<Account>();
          acc2.add(a2);
        Customer user2 = new Customer(2L, "Shruti", "4560965409", acc2);
        
	        Mockito.when(customerService.findById(sid)).thenReturn((user1));
	        Mockito.when(customerService.findById(rid)).thenReturn((user2));
	        customerService.saveOrUpdate(user1);  customerService.saveOrUpdate(user2);
            RequestBuilder request=MockMvcRequestBuilders.put("/transfer?sid=1&rid=2&funds=10").accept(MediaType.APPLICATION_JSON);
    		MvcResult mvcresult=mockMvc.perform(request).andReturn();

			//mockMvc.perform(put("/transfer?sid=1&rid=2&funds=10"))
			       assertEquals("Successfully Transfered",mvcresult.getResponse().getContentAsString());
			
	    }
	    @Test
	    void DeleteMappingTest() throws Exception {
	        Long custId = 1L;
	        List<Account> acc = new ArrayList<Account>();
			Account acc1 = new Account("Saving", 560090);
			acc.add(acc1);
			Account acc2 = new Account("Personal", 560090);
			acc.add(acc2);
          Customer c = new Customer(1L, "Shruti", "4560965409", acc);
	        Mockito.when(customerService.findById(custId)).thenReturn((c));

	     //  given(userService.findById(userId)).thenReturn(Optional.of(user));
	        customerService.delete(c.getId());

	        this.mockMvc.perform(delete("/delete/{id}", c.getId()))
	                .andExpect(status().isOk());
	               
	    }
}
